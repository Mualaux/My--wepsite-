import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { useTranslation } from "react-i18next";
import AuthForm from "@/components/AuthForm";
import ProductCard from "@/components/ProductCard";
import Cart from "@/components/Cart";

export default function HomePage() {
  const { t, i18n } = useTranslation();
  const [showLogin, setShowLogin] = useState(false);
  const [cartItems, setCartItems] = useState([]);

  const toggleLanguage = (lang) => {
    i18n.changeLanguage(lang);
    document.dir = lang === "ar" ? "rtl" : "ltr";
  };

  const addToCart = (item) => {
    setCartItems((prev) => [...prev, item]);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-white">
      <header className="flex items-center justify-between p-4 border-b border-gray-300">
        <h1 className="text-xl font-bold">DROPSHOP</h1>
        <div className="space-x-2">
          <Button variant="outline" onClick={() => toggleLanguage("en")}>EN</Button>
          <Button variant="outline" onClick={() => toggleLanguage("ar")}>AR</Button>
          <Button onClick={() => setShowLogin(true)}>{t("login")}</Button>
        </div>
      </header>

      {showLogin ? (
        <AuthForm onClose={() => setShowLogin(false)} />
      ) : (
        <main className="p-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((item) => (
            <ProductCard key={item} item={item} addToCart={addToCart} />
          ))}
        </main>
      )}

      {cartItems.length > 0 && <Cart cartItems={cartItems} />}
    </div>
  );
}