import React from "react";
import { Button } from "@/components/ui/button";
import { useTranslation } from "react-i18next";

export default function Cart({ cartItems }) {
  const { t } = useTranslation();

  return (
    <div className="fixed bottom-0 right-0 m-4 p-4 bg-white shadow-lg rounded-xl w-80 z-50">
      <h3 className="font-bold mb-2">{t("cartTitle")}</h3>
      <ul className="text-sm max-h-40 overflow-auto">
        {cartItems.map((id, index) => (
          <li key={index}>
            {t("product")} {id}
          </li>
        ))}
      </ul>
      <Button className="mt-4 w-full">{t("checkout")}</Button>
    </div>
  );
}