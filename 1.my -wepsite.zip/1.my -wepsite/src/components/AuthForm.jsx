import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useTranslation } from "react-i18next";

export default function AuthForm({ onClose }) {
  const { t } = useTranslation();
  const [isRegister, setIsRegister] = useState(false);

  return (
    <div className="p-6 flex justify-center">
      <Card className="w-full max-w-md">
        <CardContent className="p-6">
          <Tabs defaultValue="buyer" className="w-full">
            <TabsList className="grid grid-cols-2 mb-4">
              <TabsTrigger value="buyer">{t("buyer")}</TabsTrigger>
              <TabsTrigger value="seller">{t("seller")}</TabsTrigger>
            </TabsList>

            {["buyer", "seller"].map((type) => (
              <TabsContent key={type} value={type}>
                <form className="space-y-4">
                  <Input placeholder={t("email")} type="email" required />
                  <Input placeholder={t("password")} type="password" required />
                  <Button className="w-full">
                    {isRegister ? t(`registerAs${capitalize(type)}`) : t(`loginAs${capitalize(type)}`)}
                  </Button>
                </form>
              </TabsContent>
            ))}
          </Tabs>

          <Button variant="link" onClick={() => setIsRegister(!isRegister)} className="mt-4">
            {isRegister ? t("alreadyHaveAccount") : t("noAccount")}
          </Button>
          <Button variant="link" onClick={onClose} className="text-sm text-gray-500 mt-2">
            {t("close")}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

const capitalize = (s) => s.charAt(0).toUpperCase() + s.slice(1);