import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useTranslation } from "react-i18next";

export default function ProductCard({ item, addToCart }) {
  const { t } = useTranslation();

  return (
    <Card className="hover:shadow-lg transition">
      <CardContent className="p-4">
        <img
          src={`https://via.placeholder.com/300x200?text=Product+${item}`}
          alt={`Product ${item}`}
          className="rounded mb-2"
        />
        <h2 className="text-lg font-semibold mb-1">{t("productName")}</h2>
        <p className="text-sm text-gray-500">{t("productDesc")}</p>
        <div className="mt-2 font-bold">$25.00</div>
        <Button className="mt-2 w-full" onClick={() => addToCart(item)}>
          {t("addToCart")}
        </Button>
      </CardContent>
    </Card>
  );
}